#pragma once

// Compatibility header
#warning "The RBControl_wifi.hpp header is deprecated, please use rbwifi.h from the RBProtocol library.h"

#include "rbwifi.h"
